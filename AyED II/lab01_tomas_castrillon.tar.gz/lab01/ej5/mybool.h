#ifndef true 
#define true 1
#ifndef false 
#define false 0
typedef int mybool;
#endif 
#endif

